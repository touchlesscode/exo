# TMForum Data Model Documentation
This repository is used for the auto generation of TMForum Data Model Documentation