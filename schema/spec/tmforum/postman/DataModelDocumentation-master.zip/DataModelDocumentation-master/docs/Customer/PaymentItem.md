# Payment item Data Model

## Domain

The  schema is part of the  Domain

## Description

The paymentItem is the result of lettering process. It enables to assign automatically or manually part of incoming payment amount to a bill

## Data model

A JSON Schema corresponding to this data model can be found
[here](https://github.com/tmforum-rand/schemas/blob/candidates/Customer/PaymentItem.schema.json).

The Data model is defined as shown below:

- `appliedAmount` : Part of a payment amount lettered to the customer bill

  - Optional






## TMForum APIs that use this schema

Taking into consideration the snapshot of 04/02/2020 04:59:17 UTC the list of [TMForum Open APIs](https://www.tmforum.org/open-apis/) that uses this schemas is:

Coming soon