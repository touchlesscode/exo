# Cash details Data Model

## Domain

The  schema is part of the  Domain

## Description

Cash has no additional data, but it could be extended to add information (e.g.: the cashier who took the payment, the person who paid, etc)

## Data model

A JSON Schema corresponding to this data model can be found
[here](https://github.com/tmforum-rand/schemas/blob/candidates/Customer/CashDetails.schema.json).

The Data model is defined as shown below:





## TMForum APIs that use this schema

Taking into consideration the snapshot of 04/02/2020 04:59:17 UTC the list of [TMForum Open APIs](https://www.tmforum.org/open-apis/) that uses this schemas is:

Coming soon